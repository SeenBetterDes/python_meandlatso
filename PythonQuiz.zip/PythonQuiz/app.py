from flask import Flask,request,render_template,session,redirect,url_for, session
from flask import flash
from werkzeug.security import generate_password_hash, check_password_hash
from bs4 import BeautifulSoup
import requests
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import update
#---------------------------------SQL---------------------
app = Flask(__name__)
app.config['SECRET_KEY']='Python'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.sqlite'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
db.init_app(app)
db.session.commit()
# #---------------------------------Parsing-------------------------------
url = "https://fx-rate.net/GEL/"
r = requests.get(url)
content = r.text
soup = BeautifulSoup(content, 'html.parser')
money_euro = soup.find_all("a",title="Euro to Lari",href=True)
money_usd = soup.find_all("a",title="Dollar to Lari",href=True)
money_pound = soup.find_all("a",title="Pound to Lari",href=True)
#
class Users(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(25), unique=True, nullable=False)
    password = db.Column(db.String, nullable=False)
    balance = db.Column(db.Float, default=0)

# db.create_all()


@app.route('/')
def index():
    return redirect(url_for('login'))


@app.route('/sign-up', methods=['GET', 'POST'])
def signup():
    error = None
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = Users.query.filter_by(username=username).first()

        if user:
            return redirect(url_for('login'))

        db.session.add(Users(username=username,password=generate_password_hash(password, method='sha256'), balance = 5000))
        db.session.commit()
        return redirect(url_for('login'))
    else:
        return render_template('sign-up.html')

@app.route('/log-in',methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = Users.query.filter_by(username=username).first()

        if not user or not check_password_hash(user.password, password):
            flash('Please check your login details and try again.')
            return redirect(url_for('auth.login'))

        session["user"] = user.username
        session["loggedin"] = True
        return redirect(url_for('home'))

    return render_template("log-in.html", error=error)

@app.route('/home',  methods=['GET', 'POST'])
def home():
     if "user" in session:
        money_e = [item.text for item in money_euro]
        money_e_real = money_e[0]
        money_u = [item.text for item in money_usd]
        money_u_real = money_u[0]
        money_p = [item.text for item in money_pound]
        money_p_real = money_p[0]
        username = session["user"]
        user = Users.query.filter_by(username=username).first()
        return render_template('home-page.html',**locals())

@app.route('/logout')
def logout():
    if "user" in session:
        session.clear()
        return redirect(url_for('login'))

@app.route('/send',methods=['GET', 'POST'] )
def send():
    if request.method == 'POST':
        print("rame")
        if "user" in session:
            username = session["user"]
            user = Users.query.filter_by(username=username).first()
            money_e = [item.text for item in money_euro]
            money_e_real = money_e[0]
            money_u = [item.text for item in money_usd]
            money_u_real = money_u[0]
            money_p = [item.text for item in money_pound]
            money_p_real = money_p[0]
            balance = user.balance
            r = request.form.get('receiver')
            amount = request.form.get('amount')
            currency = request.form.get('money')
            receiver = Users.query.filter_by(username=r).first()
            num = 0
            # if user:
            #     return "hello"
                # if balance > 0:
                     # if amount < balance:
                     #     return "hello"

                    # if currency == "gel":
                    #     mynewbalance = balance - amount
                    #     newbalance = balance + amount
                    #     upd = (update(Users).where(Users.username== user.username).values(balance = mynewbalance))
                    #     upd = (update(Users).where(Users.username == receiver.username).values(balance=newbalance))
            #         elif currency == "euro":
            #             amount = amount * money_e_real
            #             mynewbalance = balance - amount
            #             newbalance = balance + amount
            #             upd = (update(Users).where(Users.username == user.username).values(balance=newbalance))
            #             upd = (update(Users).where(Users.username == receiver.username).values(balance=newbalance))
            #         elif currency == "usd":
            #             amount = amount * money_u_real
            #             mynewbalance = balance - amount
            #             newbalance = balance + amount
            #             upd = (update(Users).where(Users.username == user.username).values(balance=newbalance))
            #             upd = (update(Users).where(Users.username == receiver.username).values(balance=newbalance))
            #         elif currency == "pound":
            #             amount = amount * money_p_real
            #             mynewbalance = balance - amount
            #             newbalance = balance + amount
            #             upd = (update(Users).where(Users.username == user.username).values(balance=newbalance))
            #             upd = (update(Users).where(Users.username == receiver.username).values(balance=newbalance))

    else:
        return render_template('send.html', **locals())

if __name__ == '__main__':
    app.run(debug=True)
